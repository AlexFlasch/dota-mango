﻿namespace PortableSteam.Infrastructure.Attributes
{
    using System;

    /// <summary>
    /// Attribute used to mark properties that a required.
    /// </summary>
    public class RequiredAttribute : Attribute { }
}
