﻿namespace PortableSteam
{
    public enum GetMatchHistoryResponseStatus
    {
        Success = 1,
        Private = 15,
    }
}
