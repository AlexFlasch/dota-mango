﻿namespace PortableSteam
{
    public enum GetMatchHistoryBySequenceNumResponseStatus
    {
        Success = 1,
        InvalidMatchRequested = 8,
    }
}
