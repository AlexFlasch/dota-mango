﻿namespace PortableSteam
{
    public enum GetTeamInfoByTeamIDResponseStatus
    {
        Success = 1,
        InvalidTeamRequested = 8,
    }
}
