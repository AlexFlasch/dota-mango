﻿namespace PortableSteam
{
    public enum GetTournamentPlayerStatsResponseStatus
    {
        Success = 1,
        OnlySupportsInternational = 8,
    }
}
