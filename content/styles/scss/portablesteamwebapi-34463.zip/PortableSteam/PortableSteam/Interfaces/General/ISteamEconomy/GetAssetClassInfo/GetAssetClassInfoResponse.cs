﻿namespace PortableSteam.Interfaces.General.ISteamEconomy
{
    using PortableSteam.Infrastructure;

    // TODO
    public class GetAssetClassInfoResponse : ResponseBase
    {
    }
}
